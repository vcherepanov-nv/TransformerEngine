"""Combine both passes and instrumented cache layers into the report metrics."""
from collections import Counter
import csv
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET

ROOT = Path(__file__).parent
EVENTS = {
    'CREATE_GRAPH': 'Graphs created',
    'CACHE_GRAPH': 'Graphs cached',
    'BUILD_PLANS': 'Graphs compiled',
    'EXECUTE': 'Graph executions',
    'HIT': 'Cache hits',
    'MISS': 'Cache misses',
}


def cache_events(path):
    native, python = Counter(), Counter()
    for line in path.read_text().splitlines():
        match = re.match(r'\[FUSED-ATTN-CACHE\] (?:rank=\d+ \| )?tid=all\s+dev=all\s+\|\s+(?:f16|fp8) (?:fwd|bwd)\s+\|\s+(.*)', line)
        if match:
            native.update({name.upper(): int(count) for name, count in re.findall(r'(\w+)=\s*(\d+)', match[1])})
        match = re.fullmatch(r'  (?:f16|fp8) (?:fwd|bwd) (\w+)=(\d+)', line)
        if match:
            python[match[1]] += int(match[2])
    return native, python


def results(path):
    cases = {}
    for case in ET.parse(path).iter('testcase'):
        status, reason = 'passed', ''
        for tag in ('skipped', 'failure', 'error'):
            child = case.find(tag)
            if child is not None:
                status, reason = tag, child.get('message', '')
                break
        cases[case.get('classname') + '::' + case.get('name')] = (status, reason)
    return cases


data = {'method': {
    'execution': 'Observed successful EXECUTE-stage attention FFI handler invocations in the parent pytest process; native trampolines forward original handlers unchanged. Metadata queries and initialization/warm-up stages excluded.',
    'caches': 'NVTE_FUSED_ATTN_CACHE_DEBUG=1:all, summed across passes. Main Python score-mod cache events are separately instrumented and included, matching branch coverage.',
    'scope': 'L0 common suite: 5,135 identical node IDs in identical order, one fresh process per revision. Deterministic mode is a separate fresh-process measurement, not added to L0 totals.',
    'hit_counts': 'Lookup sites differ between native and Python implementations; execution counts independently establish identical runtime attention workload.',
}, 'results': {}}
csv_rows = []
for mode in ('l0', 'deterministic'):
    if not all((ROOT / f'{side}-{mode}.probe.json').exists() and (ROOT / f'{side}-{mode}.xml').exists() for side in ('main', 'branch')):
        continue
    mode_data, testcase_results = {}, {}
    for side in ('main', 'branch'):
        label = side + '-' + mode
        native, python = cache_events(ROOT / (label + '.stderr.log'))
        probe = json.loads((ROOT / (label + '.probe.json')).read_text())
        assert all(target['errors'] == 0 for target in probe['targets'].values())
        cases = results(ROOT / (label + '.xml'))
        testcase_results[side] = cases
        totals = Counter(native)
        totals.update(python)
        totals.update(probe['main_score_mod_cache'])
        if side == 'main':
            ordinary_executions = sum(item['executions'] for name, item in probe['targets'].items() if 'score_mod' not in name)
            assert ordinary_executions == native['EXECUTE']
        totals['EXECUTE'] = probe['total_executions']
        mode_data[side] = {
            'tests': dict(Counter(status for status, reason in cases.values())),
            'metrics': {label: totals[event] for event, label in EVENTS.items()},
            'native_cache_events': dict(native), 'python_cache_events': dict(python),
            'ffi_probe': probe,
        }
    assert testcase_results['main'] == testcase_results['branch']
    mode_data['common_case_count'] = len(testcase_results['main'])
    mode_data['identical_case_outcomes_and_skip_reasons'] = True
    data['results'][mode] = mode_data
    for metric in EVENTS.values():
        csv_rows.append(dict(mode=mode, Metric=metric,
                             main=mode_data['main']['metrics'][metric],
                             branch=mode_data['branch']['metrics'][metric]))
    print(mode, mode_data['main']['tests'], mode_data['branch']['tests'])
    for side in ('main', 'branch'):
        print(side, mode_data[side]['metrics'])

(ROOT / 'combined-stats.json').write_text(json.dumps(data, indent=2) + '\n')
with (ROOT / 'combined-stats.csv').open('w') as output:
    writer = csv.DictWriter(output, fieldnames=['mode', 'Metric', 'main', 'branch'])
    writer.writeheader()
    writer.writerows(csv_rows)
